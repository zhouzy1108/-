class Demo(object):
    def __init__(self, x):
        self.x = x

    def forword(self):
        print(self.x)
