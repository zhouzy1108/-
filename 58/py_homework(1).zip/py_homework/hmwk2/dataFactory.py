class dataFactory(object):
    def __int__(self):
        self.__name = "dataFactory"

    def sampling(self, **kwargs):
        raise "This is a base factory, no implement to sample data!"
